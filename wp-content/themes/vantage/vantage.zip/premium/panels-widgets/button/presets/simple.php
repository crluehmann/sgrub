<?php

return array(
	'vantage_black' => array(
		'background_color' => '#2f3033',
		'text_darken' => '-75%',
		'text_shadow' => '-30%',
		'inset_highlight' => '17%',
	),
);
