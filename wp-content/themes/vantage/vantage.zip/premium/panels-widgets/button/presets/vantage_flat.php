<?php

return array(
	'red' => array(
		'background_color' => '#db0019',
	),
	'crayola_red' => array(
		'background_color' => '#ea004a',
	),
	'orange' => array(
		'background_color' => '#f65800',
	),
	'gold' => array(
		'background_color' => '#ed9f00',
	),
	'pink' => array(
		'background_color' => '#ff73a9',
	),
	'green' => array(
		'background_color' => '#69c723',
	),
	'dark_green' => array(
		'background_color' => '#00b450',
	),
	'light_blue' => array(
		'background_color' => '#00c5ea',
	),
	'dark_blue' => array(
		'background_color' => '#0677c0',
	),
	'violet' => array(
		'background_color' => '#7113b1',
	),
	'black' => array(
		'background_color' => '#2f3033',
	),
	'white' => array(
		'background_color' => '#efefef',
		'text_lighten' => '-55%',
	),
	'grey' => array(
		'background_color' => '#9b9c9d',
	),
);
